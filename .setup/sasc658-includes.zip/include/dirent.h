/* Copyright (c) 1992-1993 SAS Institute, Inc., Cary, NC USA */
/* All Rights Reserved */


#ifndef _DIRENT_H
#define _DIRENT_H 1

#include <sys/dir.h>

#endif
