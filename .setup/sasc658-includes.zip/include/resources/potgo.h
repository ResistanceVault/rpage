#ifndef RESOURCES_POTGO_H
#define RESOURCES_POTGO_H
/*
**	$VER: potgo.h 36.0 (13.4.90)
**	Includes Release 40.13
**
**	potgo resource name
**
**	(C) Copyright 1986-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/
#define  POTGONAME	"potgo.resource"
#endif	 /* RESOURCES_POTGO_H */
