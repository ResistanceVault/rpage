#ifndef RESOURCES_CIA_H
#define RESOURCES_CIA_H
/*
**	$VER: ciabase.h 1.2 (16.5.90)
**	Includes Release 40.13
**
**	cia base definitions
**
**	(C) Copyright 1990-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/


/*
 *	There is no public information in CiaBase
 */


#endif	/* RESOURCES_CIA_H */
