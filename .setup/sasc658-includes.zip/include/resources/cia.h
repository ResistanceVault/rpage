#ifndef DEVICES_CIA_H
#define DEVICES_CIA_H 1
/*
**	$VER: cia.h 36.4 (9.1.91)
**	Includes Release 40.13
**
**	Cia resource name strings.
**
**	(C) Copyright 1985-1993 Commodore-Amiga Inc.
**		All Rights Reserved
*/

#define	CIAANAME "ciaa.resource"
#define	CIABNAME "ciab.resource"

#endif	/* DEVICES_CIA_H */
