#ifndef RESOURCES_BATTMEMBITSAMIX_H
#define RESOURCES_BATTMEMBITSAMIX_H 1
/*
**	$VER: battmembitsamix.h 1.1 (25.5.90)
**	Includes Release 40.13
**
**	BattMem Amix specific bit definitions.
**
**	(C) Copyright 1989-1993 Commodore-Amiga Inc.
**		All Rights Reserved
*/


/*
 *	See Amix documentation for these bit definitions
 *
 *	Bits 32 to 63, inclusive
 */


#endif /* RESOURCES_BATTMEMBITSAMIX_H */
