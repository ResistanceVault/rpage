#ifndef RESOURCES_BATTCLOCK_H
#define RESOURCES_BATTCLOCK_H 1
/*
**	$VER: battclock.h 36.4 (1.5.90)
**	Includes Release 40.13
**
**	BattClock resource name strings.
**
**	(C) Copyright 1989-1993 Commodore-Amiga Inc.
**		All Rights Reserved
*/

#define BATTCLOCKNAME	"battclock.resource"

#endif /* RESOURCES_BATTCLOCK_H */
