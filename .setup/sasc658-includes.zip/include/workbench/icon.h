#ifndef WORKBENCH_ICON_H
#define WORKBENCH_ICON_H
/*
**	$VER: icon.h 36.1 (26.10.90)
**	Includes Release 40.13
**
**	external declarations for icon.library
**
**	(C) Copyright 1985-1993 Commodore-Amiga, Inc.
**	All Rights Reserved
*/

#define	ICONNAME	"icon.library"

#endif	/* !WORKBENCH_ICON_H */
