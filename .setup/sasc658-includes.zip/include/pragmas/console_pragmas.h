#pragma libcall ConsoleDevice CDInputHandler 2a 9802
#pragma libcall ConsoleDevice RawKeyConvert 30 A19804
/*--- functions in V36 or higher (Release 2.0) ---*/
/*pragma libcall ConsoleDevice consolePrivate1 36 0*/
/*pragma libcall ConsoleDevice consolePrivate2 3c 0*/
/*pragma libcall ConsoleDevice consolePrivate3 42 0*/
/*pragma libcall ConsoleDevice consolePrivate4 48 0*/
