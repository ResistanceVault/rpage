#pragma libcall DiskBase AllocUnit 6 001
#pragma libcall DiskBase FreeUnit c 001
#pragma libcall DiskBase GetUnit 12 901
#pragma libcall DiskBase GiveUnit 18 0
#pragma libcall DiskBase GetUnitID 1e 001
/*------ new for V37 ------*/
#pragma libcall DiskBase ReadUnitID 24 001
