/*--- functions in V36 or higher (Release 2.0) ---*/
#pragma libcall InputBase PeekQualifier 2a 0
