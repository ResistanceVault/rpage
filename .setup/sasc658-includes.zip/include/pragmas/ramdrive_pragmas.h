/*--- functions in V34 or higher (Release 1.3) ---*/
#pragma libcall RamdriveDevice KillRAD0 2a 0
/*--- functions in V36 or higher (Release 2.0) ---*/
#pragma libcall RamdriveDevice KillRAD 30 001
