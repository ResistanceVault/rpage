/* "mathieeesingbas.library"*/
#pragma libcall MathIeeeSingBasBase IEEESPFix 1E 001
#pragma libcall MathIeeeSingBasBase IEEESPFlt 24 001
#pragma libcall MathIeeeSingBasBase IEEESPCmp 2A 1002
#pragma libcall MathIeeeSingBasBase IEEESPTst 30 001
#pragma libcall MathIeeeSingBasBase IEEESPAbs 36 001
#pragma libcall MathIeeeSingBasBase IEEESPNeg 3C 001
#pragma libcall MathIeeeSingBasBase IEEESPAdd 42 1002
#pragma libcall MathIeeeSingBasBase IEEESPSub 48 1002
#pragma libcall MathIeeeSingBasBase IEEESPMul 4E 1002
#pragma libcall MathIeeeSingBasBase IEEESPDiv 54 1002
#pragma libcall MathIeeeSingBasBase IEEESPFloor 5A 001
#pragma libcall MathIeeeSingBasBase IEEESPCeil 60 001
