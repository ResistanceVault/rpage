/*--- functions in V39 or higher (Release 3) ---*/
/**/
/* Public entries*/
/**/
#pragma libcall ColorWheelBase ConvertHSBToRGB 1e 9802
#pragma libcall ColorWheelBase ConvertRGBToHSB 24 9802
