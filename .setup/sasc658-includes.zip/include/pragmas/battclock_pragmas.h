#pragma libcall BattClockBase ResetBattClock 6 0
#pragma libcall BattClockBase ReadBattClock c 0
#pragma libcall BattClockBase WriteBattClock 12 001
/*pragma libcall BattClockBase battclockPrivate1 18 0*/
/*pragma libcall BattClockBase battclockPrivate2 1e 0*/
