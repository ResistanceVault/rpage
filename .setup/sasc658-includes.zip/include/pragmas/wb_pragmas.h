/*--- functions in V36 or higher (Release 2.0) ---*/
/*pragma libcall WorkbenchBase wbPrivate1 1e 0*/
/*pragma libcall WorkbenchBase wbPrivate2 24 0*/
/*pragma libcall WorkbenchBase wbPrivate3 2a 0*/
/**/
#pragma libcall WorkbenchBase AddAppWindowA 30 A981005
#pragma tagcall WorkbenchBase AddAppWindow 30 A981005
/**/
#pragma libcall WorkbenchBase RemoveAppWindow 36 801
/**/
#pragma libcall WorkbenchBase AddAppIconA 3c CBA981007
#pragma tagcall WorkbenchBase AddAppIcon 3c CBA981007
/**/
#pragma libcall WorkbenchBase RemoveAppIcon 42 801
/**/
#pragma libcall WorkbenchBase AddAppMenuItemA 48 A981005
#pragma tagcall WorkbenchBase AddAppMenuItem 48 A981005
/**/
#pragma libcall WorkbenchBase RemoveAppMenuItem 4e 801
/**/
/*--- functions in V39 or higher (Release 3) ---*/
/**/
/*pragma libcall WorkbenchBase wbPrivate4 54 0*/
/**/
#pragma libcall WorkbenchBase WBInfo 5a A9803
/**/
/*--- (5 function slots reserved here) ---*/
/**/
