#pragma libcall TranslatorBase Translate 1e 190804
