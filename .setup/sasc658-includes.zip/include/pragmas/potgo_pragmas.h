#pragma libcall PotgoBase AllocPotBits 6 001
#pragma libcall PotgoBase FreePotBits c 001
#pragma libcall PotgoBase WritePotgo 12 1002
