/* "mathieeesingtrans.library"*/
#pragma libcall MathIeeeSingTransBase IEEESPAtan 1E 001
#pragma libcall MathIeeeSingTransBase IEEESPSin 24 001
#pragma libcall MathIeeeSingTransBase IEEESPCos 2A 001
#pragma libcall MathIeeeSingTransBase IEEESPTan 30 001
#pragma libcall MathIeeeSingTransBase IEEESPSincos 36 0802
#pragma libcall MathIeeeSingTransBase IEEESPSinh 3C 001
#pragma libcall MathIeeeSingTransBase IEEESPCosh 42 001
#pragma libcall MathIeeeSingTransBase IEEESPTanh 48 001
#pragma libcall MathIeeeSingTransBase IEEESPExp 4E 001
#pragma libcall MathIeeeSingTransBase IEEESPLog 54 001
#pragma libcall MathIeeeSingTransBase IEEESPPow 5A 0102
#pragma libcall MathIeeeSingTransBase IEEESPSqrt 60 001
#pragma libcall MathIeeeSingTransBase IEEESPTieee 66 001
#pragma libcall MathIeeeSingTransBase IEEESPFieee 6C 001
#pragma libcall MathIeeeSingTransBase IEEESPAsin 72 001
#pragma libcall MathIeeeSingTransBase IEEESPAcos 78 001
#pragma libcall MathIeeeSingTransBase IEEESPLog10 7E 001
