/*--- functions in V33 or higher (Release 1.2) ---*/
/*--- (16 function slots reserved here) ---*/
/**/
#pragma libcall RexxSysBase CreateArgstring 7e 0802
#pragma libcall RexxSysBase DeleteArgstring 84 801
#pragma libcall RexxSysBase LengthArgstring 8a 801
#pragma libcall RexxSysBase CreateRexxMsg 90 09803
#pragma libcall RexxSysBase DeleteRexxMsg 96 801
#pragma libcall RexxSysBase ClearRexxMsg 9c 0802
#pragma libcall RexxSysBase FillRexxMsg a2 10803
#pragma libcall RexxSysBase IsRexxMsg a8 801
/**/
/*--- (46 function slots reserved here) ---*/
/**/
#pragma libcall RexxSysBase LockRexxBase 1c2 001
#pragma libcall RexxSysBase UnlockRexxBase 1c8 001
/**/
