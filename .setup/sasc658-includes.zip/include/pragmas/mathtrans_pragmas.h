/* "mathtrans.library"*/
#pragma libcall MathTransBase SPAtan 1E 001
#pragma libcall MathTransBase SPSin 24 001
#pragma libcall MathTransBase SPCos 2A 001
#pragma libcall MathTransBase SPTan 30 001
#pragma libcall MathTransBase SPSincos 36 0102
#pragma libcall MathTransBase SPSinh 3C 001
#pragma libcall MathTransBase SPCosh 42 001
#pragma libcall MathTransBase SPTanh 48 001
#pragma libcall MathTransBase SPExp 4E 001
#pragma libcall MathTransBase SPLog 54 001
#pragma libcall MathTransBase SPPow 5A 0102
#pragma libcall MathTransBase SPSqrt 60 001
#pragma libcall MathTransBase SPTieee 66 001
#pragma libcall MathTransBase SPFieee 6C 001
/*--- functions in V31 or higher (distributed as Release 1.1) ---*/
#pragma libcall MathTransBase SPAsin 72 001
#pragma libcall MathTransBase SPAcos 78 001
#pragma libcall MathTransBase SPLog10 7E 001
