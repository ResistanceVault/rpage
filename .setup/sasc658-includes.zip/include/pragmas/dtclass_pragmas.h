/* "dtclass.class"*/
/*--- functions in V39 or higher (distributed as Release 3.0) ---*/
/**/
#pragma libcall DTClassBase ObtainEngine 1e 0
