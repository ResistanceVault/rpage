/* "mathieeedoubbas.library"*/
#pragma libcall MathIeeeDoubBasBase IEEEDPFix 1E 001
#pragma libcall MathIeeeDoubBasBase IEEEDPFlt 24 001
#pragma libcall MathIeeeDoubBasBase IEEEDPCmp 2A 2002
#pragma libcall MathIeeeDoubBasBase IEEEDPTst 30 001
#pragma libcall MathIeeeDoubBasBase IEEEDPAbs 36 001
#pragma libcall MathIeeeDoubBasBase IEEEDPNeg 3C 001
#pragma libcall MathIeeeDoubBasBase IEEEDPAdd 42 2002
#pragma libcall MathIeeeDoubBasBase IEEEDPSub 48 2002
#pragma libcall MathIeeeDoubBasBase IEEEDPMul 4E 2002
#pragma libcall MathIeeeDoubBasBase IEEEDPDiv 54 2002
/*--- functions in V33 or higher (distributed as Release 1.2) ---*/
#pragma libcall MathIeeeDoubBasBase IEEEDPFloor 5A 001
#pragma libcall MathIeeeDoubBasBase IEEEDPCeil 60 001
