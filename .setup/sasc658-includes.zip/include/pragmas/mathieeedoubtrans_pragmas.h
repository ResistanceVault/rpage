/* "mathieeedoubtrans.library"*/
#pragma libcall MathIeeeDoubTransBase IEEEDPAtan 1E 001
#pragma libcall MathIeeeDoubTransBase IEEEDPSin 24 001
#pragma libcall MathIeeeDoubTransBase IEEEDPCos 2A 001
#pragma libcall MathIeeeDoubTransBase IEEEDPTan 30 001
#pragma libcall MathIeeeDoubTransBase IEEEDPSincos 36 0802
#pragma libcall MathIeeeDoubTransBase IEEEDPSinh 3C 001
#pragma libcall MathIeeeDoubTransBase IEEEDPCosh 42 001
#pragma libcall MathIeeeDoubTransBase IEEEDPTanh 48 001
#pragma libcall MathIeeeDoubTransBase IEEEDPExp 4E 001
#pragma libcall MathIeeeDoubTransBase IEEEDPLog 54 001
#pragma libcall MathIeeeDoubTransBase IEEEDPPow 5A 0202
#pragma libcall MathIeeeDoubTransBase IEEEDPSqrt 60 001
#pragma libcall MathIeeeDoubTransBase IEEEDPTieee 66 001
#pragma libcall MathIeeeDoubTransBase IEEEDPFieee 6C 001
#pragma libcall MathIeeeDoubTransBase IEEEDPAsin 72 001
#pragma libcall MathIeeeDoubTransBase IEEEDPAcos 78 001
#pragma libcall MathIeeeDoubTransBase IEEEDPLog10 7E 001
