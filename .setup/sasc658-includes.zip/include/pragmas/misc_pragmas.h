#pragma libcall MiscBase AllocMiscResource 6 9002
#pragma libcall MiscBase FreeMiscResource c 001
