/* "CiaA.Resource" and "CiaB.Resource"*/
#pragma libcall CiaBase AddICRVector 6 90E03
#pragma libcall CiaBase RemICRVector C 90E03
#pragma libcall CiaBase AbleICR 12 0E02
#pragma libcall CiaBase SetICR 18 0E02
