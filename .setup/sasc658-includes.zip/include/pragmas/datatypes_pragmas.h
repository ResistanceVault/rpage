/*--- functions in V40 or higher (Release 3.1) ---*/
/*pragma libcall DataTypesBase datatypesPrivate1 1e 0*/
/**/
/* Public entries*/
/**/
#pragma libcall DataTypesBase ObtainDataTypeA 24 98003
#pragma tagcall DataTypesBase ObtainDataType 24 98003
#pragma libcall DataTypesBase ReleaseDataType 2a 801
#pragma libcall DataTypesBase NewDTObjectA 30 8002
#pragma tagcall DataTypesBase NewDTObject 30 8002
#pragma libcall DataTypesBase DisposeDTObject 36 801
#pragma libcall DataTypesBase SetDTAttrsA 3c BA9804
#pragma tagcall DataTypesBase SetDTAttrs 3c BA9804
#pragma libcall DataTypesBase GetDTAttrsA 42 A802
#pragma tagcall DataTypesBase GetDTAttrs 42 A802
#pragma libcall DataTypesBase AddDTObject 48 0A9804
#pragma libcall DataTypesBase RefreshDTObjectA 4e BA9804
#pragma tagcall DataTypesBase RefreshDTObject 4e BA9804
#pragma libcall DataTypesBase DoAsyncLayout 54 9802
#pragma libcall DataTypesBase DoDTMethodA 5a BA9804
#pragma tagcall DataTypesBase DoDTMethod 5a BA9804
#pragma libcall DataTypesBase RemoveDTObject 60 9802
#pragma libcall DataTypesBase GetDTMethods 66 801
#pragma libcall DataTypesBase GetDTTriggerMethods 6c 801
#pragma libcall DataTypesBase PrintDTObjectA 72 BA9804
#pragma tagcall DataTypesBase PrintDTObject 72 BA9804
/*pragma libcall DataTypesBase datatypesPrivate2 78 0*/
/*pragma libcall DataTypesBase datatypesPrivate3 7e 0*/
/*pragma libcall DataTypesBase datatypesPrivate4 84 0*/
#pragma libcall DataTypesBase GetDTString 8a 001
