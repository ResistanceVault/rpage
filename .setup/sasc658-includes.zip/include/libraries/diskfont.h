#ifndef	LIBRARIES_DISKFONT_H
#define	LIBRARIES_DISKFONT_H
/*
**	$VER: diskfont.h 36.6 (26.11.90)
**	Includes Release 40.13
**
**	diskfont library definitions
**
**	(C) Copyright 1985-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef	DISKFONT_DISKFONT_H
#include "diskfont/diskfont.h"
#endif

#endif	/* LIBRARIES_DISKFONT_H */
