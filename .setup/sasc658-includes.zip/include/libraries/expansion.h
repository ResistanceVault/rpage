#ifndef LIBRARIES_EXPANSION_H
#define	LIBRARIES_EXPANSION_H
/*
**	$VER: expansion.h 36.7 (28.5.90)
**	Includes Release 40.13
**
**	External definitions for expansion.library
**
**	(C) Copyright 1985-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/

#define EXPANSIONNAME	"expansion.library"

/* flags for the AddDosNode() call */
#define ADNB_STARTPROC	0
#define ADNF_STARTPROC	(1L<<0)

#endif /* LIBRARIES_EXPANSION_H */
