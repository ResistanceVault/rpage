#ifndef LIBRARIES_DOS_H
#define LIBRARIES_DOS_H
/*
**	$VER: dos.h 36.2 (12.7.90)
**	Includes Release 40.13
**
**	Standard C header for AmigaDOS
**
**	(C) Copyright 1985-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef DOS_DOS_H
#include "dos/dos.h"
#endif

#endif /* LIBRARIES_DOS_H */
