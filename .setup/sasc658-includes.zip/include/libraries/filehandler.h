#ifndef LIBRARIES_FILEHANDLER_H
#define LIBRARIES_FILEHANDLER_H
/*
**	$VER: filehandler.h 36.2 (12.7.90)
**	Includes Release 40.13
**
**	device and file handler specific code for AmigaDOS
**
**	(C) Copyright 1986-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef DOS_FILEHANDLER_H
#include "dos/filehandler.h"
#endif

#endif /* LIBRARIES_FILEHANDLER_H */
