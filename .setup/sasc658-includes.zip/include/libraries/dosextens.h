#ifndef LIBRARIES_DOSEXTENS_H
#define LIBRARIES_DOSEXTENS_H
/*
**	$VER: dosextens.h 36.2 (12.7.90)
**	Includes Release 40.13
**
**	DOS structures not needed for the casual AmigaDOS user
**
**	(C) Copyright 1985-1993 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef DOS_DOSEXTENS_H
#include "dos/dosextens.h"
#endif

#endif /* LIBRARIES_DOSEXTENS_H */
