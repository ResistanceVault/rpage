#ifndef PROTO_MATHIEEEDOUBBAS_H
#define PROTO_MATHIEEEDOUBBAS_H
#include <exec/types.h>
extern struct Library *MathIeeeDoubBasBase ;
#include <clib/mathieeedoubbas_protos.h>
#include <pragmas/mathieeedoubbas_pragmas.h>
#endif
