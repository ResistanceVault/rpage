#ifndef PROTO_MATHTRANS_H
#define PROTO_MATHTRANS_H
#include <exec/types.h>
extern struct Library *MathTransBase ;
#include <clib/mathtrans_protos.h>
#include <pragmas/mathtrans_pragmas.h>
#endif
