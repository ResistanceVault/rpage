#ifndef PROTO_LOWLEVEL_H
#define PROTO_LOWLEVEL_H
#include <exec/types.h>
extern struct Library *LowLevelBase ;
#include <clib/lowlevel_protos.h>
#include <pragmas/lowlevel_pragmas.h>
#endif
