#ifndef PROTO_REXXSYSLIB_H
#define PROTO_REXXSYSLIB_H
#include <exec/types.h>
extern struct Library *RexxSysBase ;
#include <clib/rexxsyslib_protos.h>
#include <pragmas/rexxsyslib_pragmas.h>
#endif
