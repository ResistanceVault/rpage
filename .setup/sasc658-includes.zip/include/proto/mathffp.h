#ifndef PROTO_MATHFFP_H
#define PROTO_MATHFFP_H
#include <exec/types.h>
extern struct Library *MathBase ;
#include <clib/mathffp_protos.h>
#include <pragmas/mathffp_pragmas.h>
#endif
