#ifndef PROTO_INPUT_H
#define PROTO_INPUT_H
#include <exec/types.h>
extern struct Library *InputBase ;
#include <clib/input_protos.h>
#include <pragmas/input_pragmas.h>
#endif
