#ifndef PROTO_GRAPHICS_H
#define PROTO_GRAPHICS_H
#include <exec/types.h>
extern struct GfxBase *GfxBase ;
#include <clib/graphics_protos.h>
#include <pragmas/graphics_pragmas.h>
#endif
