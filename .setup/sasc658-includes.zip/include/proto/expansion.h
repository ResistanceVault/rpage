#ifndef PROTO_EXPANSION_H
#define PROTO_EXPANSION_H
#include <exec/types.h>
extern struct Library *ExpansionBase ;
#include <clib/expansion_protos.h>
#include <pragmas/expansion_pragmas.h>
#endif
