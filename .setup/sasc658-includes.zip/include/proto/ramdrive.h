#ifndef PROTO_RAMDRIVE_H
#define PROTO_RAMDRIVE_H
#include <exec/types.h>
extern struct Library *RamdriveDevice ;
#include <clib/ramdrive_protos.h>
#include <pragmas/ramdrive_pragmas.h>
#endif
