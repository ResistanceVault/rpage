#ifndef PROTO_POTGO_H
#define PROTO_POTGO_H
#include <exec/types.h>
extern struct Library *PotgoBase ;
#include <clib/potgo_protos.h>
#include <pragmas/potgo_pragmas.h>
#endif
