#ifndef PROTO_BULLET_H
#define PROTO_BULLET_H
#include <exec/types.h>
extern struct Library *BulletBase ;
#include <clib/bullet_protos.h>
#include <pragmas/bullet_pragmas.h>
#endif
