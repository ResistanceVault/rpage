#ifndef PROTO_BATTMEM_H
#define PROTO_BATTMEM_H
#include <exec/types.h>
extern struct Library *BattMemBase ;
#include <clib/battmem_protos.h>
#include <pragmas/battmem_pragmas.h>
#endif
