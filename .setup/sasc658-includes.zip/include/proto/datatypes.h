#ifndef PROTO_DATATYPES_H
#define PROTO_DATATYPES_H
#include <exec/types.h>
extern struct Library *DataTypesBase ;
#include <clib/datatypes_protos.h>
#include <pragmas/datatypes_pragmas.h>
#endif
