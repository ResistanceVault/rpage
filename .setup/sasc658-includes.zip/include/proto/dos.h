#ifndef PROTO_DOS_H
#define PROTO_DOS_H
#include <exec/types.h>
extern struct DosLibrary *DOSBase ;
#include <clib/dos_protos.h>
#include <pragmas/dos_pragmas.h>
#endif
