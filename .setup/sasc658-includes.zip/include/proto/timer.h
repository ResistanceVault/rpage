#ifndef PROTO_TIMER_H
#define PROTO_TIMER_H
#include <exec/types.h>
extern struct Library *TimerBase ;
#include <clib/timer_protos.h>
#include <pragmas/timer_pragmas.h>
#endif
