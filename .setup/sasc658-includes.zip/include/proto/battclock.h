#ifndef PROTO_BATTCLOCK_H
#define PROTO_BATTCLOCK_H
#include <exec/types.h>
extern struct Library *BattClockBase ;
#include <clib/battclock_protos.h>
#include <pragmas/battclock_pragmas.h>
#endif
