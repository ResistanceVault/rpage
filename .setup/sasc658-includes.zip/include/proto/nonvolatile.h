#ifndef PROTO_NONVOLATILE_H
#define PROTO_NONVOLATILE_H
#include <exec/types.h>
extern struct Library *NVBase ;
#include <clib/nonvolatile_protos.h>
#include <pragmas/nonvolatile_pragmas.h>
#endif
