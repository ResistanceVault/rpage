#ifndef PROTO_MISC_H
#define PROTO_MISC_H
#include <exec/types.h>
extern struct Library *MiscBase;
#include <clib/misc_protos.h>
#include <pragmas/misc_pragmas.h>
#endif
