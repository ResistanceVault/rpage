#ifndef PROTO_CARDRES_H
#define PROTO_CARDRES_H
#include <exec/types.h>
extern struct Library *CardResource ;
#include <clib/cardres_protos.h>
#include <pragmas/cardres_pragmas.h>
#endif
