#ifndef PROTO_MATHIEEESINGTRANS_H
#define PROTO_MATHIEEESINGTRANS_H
#include <exec/types.h>
extern struct Library *MathIeeeSingTransBase ;
#include <clib/mathieeesingtrans_protos.h>
#include <pragmas/mathieeesingtrans_pragmas.h>
#endif
