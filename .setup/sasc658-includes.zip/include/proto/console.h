#ifndef PROTO_CONSOLE_H
#define PROTO_CONSOLE_H
#include <exec/types.h>
extern struct Library *ConsoleDevice ;
#include <clib/console_protos.h>
#include <pragmas/console_pragmas.h>
#endif
