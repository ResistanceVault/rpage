#ifndef PROTO_LAYERS_H
#define PROTO_LAYERS_H
#include <exec/types.h>
extern struct Library *LayersBase ;
#include <clib/layers_protos.h>
#include <pragmas/layers_pragmas.h>
#endif
