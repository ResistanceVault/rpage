#ifndef PROTO_WB_H
#define PROTO_WB_H
#include <exec/types.h>
extern struct Library *WorkbenchBase ;
#include <clib/wb_protos.h>
#include <pragmas/wb_pragmas.h>
#endif
