#ifndef PROTO_MATHIEEESINGBAS_H
#define PROTO_MATHIEEESINGBAS_H
#include <exec/types.h>
extern struct Library *MathIeeeSingBasBase ;
#include <clib/mathieeesingbas_protos.h>
#include <pragmas/mathieeesingbas_pragmas.h>
#endif
