#ifndef PROTO_ICON_H
#define PROTO_ICON_H
#include <exec/types.h>
extern struct Library *IconBase ;
#include <clib/icon_protos.h>
#include <pragmas/icon_pragmas.h>
#endif
