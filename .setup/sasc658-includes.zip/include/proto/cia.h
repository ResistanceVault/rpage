#ifndef PROTO_CIA_H
#define PROTO_CIA_H
#include <exec/types.h>
extern struct Library *CiaBase ;
#include <clib/cia_protos.h>
#include <pragmas/cia_pragmas.h>
#endif
