#ifndef PROTO_KEYMAP_H
#define PROTO_KEYMAP_H
#include <exec/types.h>
extern struct Library *KeymapBase ;
#include <clib/keymap_protos.h>
#include <pragmas/keymap_pragmas.h>
#endif
