#ifndef PROTO_TRANSLATOR_H
#define PROTO_TRANSLATOR_H
#include <exec/types.h>
extern struct Library *TranslatorBase ;
#include <clib/translator_protos.h>
#include <pragmas/translator_pragmas.h>
#endif
