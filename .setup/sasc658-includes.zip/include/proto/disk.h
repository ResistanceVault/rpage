#ifndef PROTO_DISK_H
#define PROTO_DISK_H
#include <exec/types.h>
extern struct Library *DiskBase ;
#include <clib/disk_protos.h>
#include <pragmas/disk_pragmas.h>
#endif

