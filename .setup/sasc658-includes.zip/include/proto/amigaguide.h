#ifndef PROTO_AMIGAGUIDE_H
#define PROTO_AMIGAGUIDE_H
#include <exec/types.h>
extern struct Library *AmigaGuideBase ;
#include <clib/amigaguide_protos.h>
#include <pragmas/amigaguide_pragmas.h>
#endif
