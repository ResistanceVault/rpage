#ifndef PROTO_DTCLASS_H
#define PROTO_DTCLASS_H
#include <exec/types.h>
extern struct Library *DTClassBase ;
#include <clib/dtclass_protos.h>
#include <pragmas/dtclass_pragmas.h>
#endif
