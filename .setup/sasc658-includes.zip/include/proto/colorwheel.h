#ifndef PROTO_COLORWHEEL_H
#define PROTO_COLORWHEEL_H
#include <exec/types.h>
extern struct Library *ColorWheelBase ;
#include <clib/colorwheel_protos.h>
#include <pragmas/colorwheel_pragmas.h>
#endif
