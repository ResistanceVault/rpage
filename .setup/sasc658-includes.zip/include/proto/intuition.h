#ifndef PROTO_INTUITION_H
#define PROTO_INTUITION_H
#include <exec/types.h>
extern struct IntuitionBase *IntuitionBase ;
#include <clib/intuition_protos.h>
#include <pragmas/intuition_pragmas.h>
#endif
