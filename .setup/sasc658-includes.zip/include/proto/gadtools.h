#ifndef PROTO_GADTOOLS_H
#define PROTO_GADTOOLS_H
#include <exec/types.h>
extern struct Library *GadToolsBase ;
#include <clib/gadtools_protos.h>
#include <pragmas/gadtools_pragmas.h>
#endif