#ifndef PROTO_LOCALE_H
#define PROTO_LOCALE_H
#include <exec/types.h>
extern struct Library *LocaleBase ;
#include <clib/locale_protos.h>
#include <pragmas/locale_pragmas.h>
#endif
