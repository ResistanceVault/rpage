#ifndef PROTO_DISKFONT_H
#define PROTO_DISKFONT_H
#include <exec/types.h>
extern struct Library *DiskfontBase ;
#include <clib/diskfont_protos.h>
#include <pragmas/diskfont_pragmas.h>
#endif
