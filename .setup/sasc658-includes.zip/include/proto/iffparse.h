#ifndef PROTO_IFFPARSE_H
#define PROTO_IFFPARSE_H
#include <exec/types.h>
extern struct Library *IFFParseBase ;
#include <clib/iffparse_protos.h>
#include <pragmas/iffparse_pragmas.h>
#endif
