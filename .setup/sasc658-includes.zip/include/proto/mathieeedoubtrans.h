#ifndef PROTO_MATHIEDDDDOUBTRANS_H
#define PROTO_MATHIEDDDDOUBTRANS_H
#include <exec/types.h>
extern struct Library *MathIeeeDoubTransBase ;
#include <clib/mathieeedoubtrans_protos.h>
#include <pragmas/mathieeedoubtrans_pragmas.h>
#endif
