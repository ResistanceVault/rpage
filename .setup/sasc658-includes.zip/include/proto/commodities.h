#ifndef PROTO_COMMODITIES_H
#define PROTO_COMMODITIES_H
#include <exec/types.h>
extern struct Library *CxBase ;
#include <clib/commodities_protos.h>
#include <pragmas/commodities_pragmas.h>
#endif
