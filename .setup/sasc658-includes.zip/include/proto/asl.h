#ifndef PROTO_ASL_H
#define PROTO_ASL_H
#include <exec/types.h>
extern struct Library *AslBase ;
#include <clib/asl_protos.h>
#include <pragmas/asl_pragmas.h>
#endif
