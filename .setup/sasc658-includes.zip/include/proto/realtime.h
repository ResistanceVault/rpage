#ifndef PROTO_REALTIME_H
#define PROTO_REALTIME_H
#include <exec/types.h>
extern struct Library *RealTimeBase ;
#include <clib/realtime_protos.h>
#include <pragmas/realtime_pragmas.h>
#endif
