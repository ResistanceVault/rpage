#ifndef PROTO_UTILITY_H
#define PROTO_UTILITY_H
#include <exec/types.h>
extern struct Library *UtilityBase ;
#include <clib/utility_protos.h>
#include <pragmas/utility_pragmas.h>
#endif
